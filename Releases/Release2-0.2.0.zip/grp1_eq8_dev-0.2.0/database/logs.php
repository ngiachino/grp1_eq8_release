<?php
$dbserver ='localhost';
$dbuser = 'aouldamara';
$password = 'cdp';
$dbname = "aouldamara";