
<!DOCTYPE html>
<html lang="fr">

<head>
    <?php include './defaultHead.php'; ?>
    <title>Tasks - GoProject</title>
    <link href="../../assets/projet.css" rel="stylesheet">
</head>

<body>
<?php include 'navbar.php'; ?>

<div class="supercontainer">
    <div class="container" id="tasks">
        <h2>Les tâches</h2>
    </div>
</div>

</body>
</html>
