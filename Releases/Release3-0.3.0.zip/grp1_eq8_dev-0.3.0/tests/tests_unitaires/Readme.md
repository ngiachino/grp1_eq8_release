# Tests unitaires

Pour l'exécution des tests, vous devez avoir phpunit d'installé sur votre machine.

## Lancer les tests
Exécutez la commande suivante, dans le dossier /tests/tests_unitaires (dossier courant):
```
phpunit .
```