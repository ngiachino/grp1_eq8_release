<?php
$dbserver ='localhost';
$dbuser = 'root';
$password = '';
$dbname = "cdp";
?>