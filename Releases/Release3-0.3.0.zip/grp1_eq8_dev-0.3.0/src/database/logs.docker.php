<?php
$dbserver ='db';
$dbuser = 'root';
$password = 'root';
$dbname = "cdp";
