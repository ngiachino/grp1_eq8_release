<?php
include_once "app/view/index.php";
?>